package com.pyittainghtaung.robotcar;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    RobotView view;
    BluetoothAdapter btAdapter;
    BluetoothSocket socket;
    OutputStream out;
    InputStream in;
    boolean connected=false;
    final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    final int REQ_BT_PERMS = 77;
    final int REQ_ENABLE_BT = 78;
    Handler ui = new Handler(Looper.getMainLooper());
    BroadcastReceiver discoveryReceiver;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        view=new RobotView(this);
        setContentView(view);
        BluetoothManager manager = (BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        btAdapter = manager != null ? manager.getAdapter() : BluetoothAdapter.getDefaultAdapter();
        ensureBluetoothPermissions(false);
    }

    boolean hasBtPermission(String perm){
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    boolean hasNeededBluetoothPermissions(){
        if(Build.VERSION.SDK_INT >= 31){
            return hasBtPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    && hasBtPermission(Manifest.permission.BLUETOOTH_SCAN);
        }
        if(Build.VERSION.SDK_INT >= 23){
            return hasBtPermission(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        return true;
    }

    boolean ensureBluetoothPermissions(boolean openAfterGrant){
        if(hasNeededBluetoothPermissions()) return true;
        ArrayList<String> req = new ArrayList<>();
        if(Build.VERSION.SDK_INT >= 31){
            req.add(Manifest.permission.BLUETOOTH_CONNECT);
            req.add(Manifest.permission.BLUETOOTH_SCAN);
        } else if(Build.VERSION.SDK_INT >= 23){
            req.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        requestPermissions(req.toArray(new String[0]), openAfterGrant ? REQ_BT_PERMS : REQ_BT_PERMS + 1);
        return false;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean ok = true;
        for(int g: grantResults) if(g != PackageManager.PERMISSION_GRANTED) ok = false;
        if(ok){
            toast("Bluetooth permission OK");
            if(requestCode == REQ_BT_PERMS) showBtPicker();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Bluetooth Permission Needed")
                    .setMessage("Nearby device permission is required to scan and connect to the robot. Please allow Bluetooth access and try again.")
                    .setPositiveButton("Try Again", (d,w)->ensureBluetoothPermissions(true))
                    .setNegativeButton("App Settings", (d,w)->startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:"+getPackageName()))))
                    .show();
        }
    }

    void showBtPicker(){
        if(!ensureBluetoothPermissions(true)) return;
        if(btAdapter==null){toast("Bluetooth not supported");return;}
        if(!btAdapter.isEnabled()){
            if(Build.VERSION.SDK_INT >= 31 && !hasBtPermission(Manifest.permission.BLUETOOTH_CONNECT)){ ensureBluetoothPermissions(true); return; }
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE_BT);
            return;
        }
        showDeviceDialog();
    }

    void showDeviceDialog(){
        final ArrayList<BluetoothDevice> devices = new ArrayList<>();
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        ListView list = new ListView(this);
        list.setAdapter(adapter);
        TextView hint = new TextView(this);
        hint.setPadding(30,20,30,10);
        hint.setText("Scanning nearby Bluetooth devices. Tap a device to connect.");
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.addView(hint);
        wrap.addView(list, new LinearLayout.LayoutParams(-1, 650));

        Dialog dialog = new AlertDialog.Builder(this)
                .setTitle("Connect Robot Bluetooth")
                .setView(wrap)
                .setPositiveButton("SCAN NEW", null)
                .setNegativeButton("CANCEL", null)
                .setNeutralButton("PHONE BT SETTINGS", null)
                .create();

        dialog.setOnShowListener(d -> {
            Button scanBtn = ((AlertDialog)dialog).getButton(AlertDialog.BUTTON_POSITIVE);
            Button settingsBtn = ((AlertDialog)dialog).getButton(AlertDialog.BUTTON_NEUTRAL);
            scanBtn.setOnClickListener(v -> startDiscovery(devices, adapter));
            settingsBtn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
            startDiscovery(devices, adapter);
        });
        list.setOnItemClickListener((parent, v, pos, id) -> {
            if(pos >= 0 && pos < devices.size()){
                stopDiscovery();
                dialog.dismiss();
                connect(devices.get(pos));
            }
        });
        dialog.setOnDismissListener(d -> stopDiscovery());
        dialog.show();
    }

    void addDevice(ArrayList<BluetoothDevice> devices, ArrayAdapter<String> adapter, BluetoothDevice dev, boolean paired){
        if(dev == null) return;
        String addr = dev.getAddress();
        for(BluetoothDevice d: devices) if(d.getAddress().equals(addr)) return;
        devices.add(dev);
        String name;
        try{ name = dev.getName(); }catch(SecurityException e){ name = "Bluetooth Device"; }
        if(name == null || name.trim().isEmpty()) name = "Unknown Device";
        adapter.add(name + "\n" + addr);
        adapter.notifyDataSetChanged();
    }

    void loadBondedDevices(ArrayList<BluetoothDevice> devices, ArrayAdapter<String> adapter){
        adapter.clear(); devices.clear();
        try{
            Set<BluetoothDevice> bonded = btAdapter.getBondedDevices();
            for(BluetoothDevice d: bonded){
                String name = d.getName();
                if(name != null && !name.trim().isEmpty()) addDevice(devices, adapter, d, false);
            }
            if(devices.isEmpty()) adapter.add("No nearby device found yet. Press SCAN NEW.");
        } catch(SecurityException e){
            toast("Need Bluetooth Connect permission");
        }
    }

    void startDiscovery(ArrayList<BluetoothDevice> devices, ArrayAdapter<String> adapter){
        if(!ensureBluetoothPermissions(true)) return;
        adapter.clear();
        devices.clear();
        stopDiscovery();
        toast("Scanning Bluetooth devices...");
        discoveryReceiver = new BroadcastReceiver(){
            @Override public void onReceive(Context context, Intent intent){
                String action = intent.getAction();
                if(BluetoothDevice.ACTION_FOUND.equals(action)){
                    BluetoothDevice dev = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    addDevice(devices, adapter, dev, false);
                } else if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)){
                    toast("Scan finished");
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_FOUND);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(discoveryReceiver, f);
        try{ btAdapter.startDiscovery(); }catch(SecurityException e){ toast("Need Bluetooth Scan permission"); }
    }

    void stopDiscovery(){
        try{ if(btAdapter != null && btAdapter.isDiscovering()) btAdapter.cancelDiscovery(); }catch(Exception ignored){}
        if(discoveryReceiver != null){
            try{ unregisterReceiver(discoveryReceiver); }catch(Exception ignored){}
            discoveryReceiver = null;
        }
    }

    void connect(BluetoothDevice dev){
        new Thread(()->{
            try{
                closeBt();
                if(Build.VERSION.SDK_INT >= 31 && !hasBtPermission(Manifest.permission.BLUETOOTH_CONNECT)){
                    runOnUiThread(()->ensureBluetoothPermissions(true));
                    return;
                }
                stopDiscovery();
                socket=dev.createRfcommSocketToServiceRecord(SPP);
                btAdapter.cancelDiscovery();
                socket.connect();
                out=socket.getOutputStream();
                in=socket.getInputStream();
                connected=true;
                send("APP:CONNECTED");
                runOnUiThread(()->{view.connected=true;view.invalidate();toast("Connected: "+safeDeviceName(dev));});
                readLoop();
            }catch(Exception e){
                connected=false;
                runOnUiThread(()->{view.connected=false;view.invalidate();toast("Connect failed. Pair robot first, then try again.");});
            }
        }).start();
    }

    String safeDeviceName(BluetoothDevice d){ try{String n=d.getName(); return n==null?d.getAddress():n;}catch(Exception e){return "Robot";} }
    void readLoop(){ byte[] buf=new byte[256]; StringBuilder sb=new StringBuilder(); try{ int n; while((n=in.read(buf))>0){ for(int i=0;i<n;i++){ char c=(char)buf[i]; if(c=='\n'){parseLine(sb.toString().trim()); sb.setLength(0);} else if(c!='\r') sb.append(c); } } }catch(Exception ignored){} }
    void parseLine(String s){ runOnUiThread(()->{ if(s.startsWith("DIST:")){try{view.distance=Float.parseFloat(s.substring(5));}catch(Exception ignored){}} if(s.startsWith("STATUS:")) view.status=s.substring(7).toUpperCase(Locale.US); view.invalidate(); }); }
    void send(String cmd){ try{ if(out!=null){ out.write((cmd+"\n").getBytes()); out.flush(); } }catch(Exception e){connected=false; view.connected=false; view.invalidate();} }
    void closeBt(){try{if(socket!=null)socket.close();}catch(Exception ignored){} socket=null; out=null; in=null; connected=false;}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){stopDiscovery();closeBt();super.onDestroy();}

    class RobotView extends View{
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        RectF screenR=new RectF();
        float W,H,scale;
        boolean connected=false, running=false, usSafe=false, irSafe=false;
        int gear=2;
        String light="LIGHTS OFF", status="READY";
        float distance=12.6f, joyX=0, joyY=0, speed=50;
        long lastJoy=0;

        RectF btR=new RectF(), settingsR=new RectF(), startStopR=new RectF(), usToggleR=new RectF(), irToggleR=new RectF(), speedBarR=new RectF(), speedKnobR=new RectF(), profileR=new RectF(), danceR=new RectF(), scaredR=new RectF(), petR=new RectF();
        RectF upArrowR=new RectF(), downArrowR=new RectF(), leftArrowR=new RectF(), rightArrowR=new RectF(), centerArrowR=new RectF();
        RectF[] gearLevelR=new RectF[3];
        RectF[] lightR=new RectF[5];
        float joyCx, joyCy, joyRad;
        int activeDirection=0;

        final int bgTop=Color.rgb(3,7,14), bgBottom=Color.rgb(2,4,10), panelTop=Color.rgb(9,13,23), panelBottom=Color.rgb(5,8,14), panelStroke=Color.rgb(30,40,62), accent=Color.rgb(41,130,255), cyan=Color.rgb(36,222,255), green=Color.rgb(39,232,58), yellow=Color.rgb(255,206,61), red=Color.rgb(255,74,74), orange=Color.rgb(255,152,43), purple=Color.rgb(178,82,255), pink=Color.rgb(255,110,210), white=Color.rgb(238,243,255), muted=Color.rgb(148,156,178);

        RobotView(Context c){
            super(c);
            setBackgroundColor(Color.BLACK);
            for(int i=0;i<lightR.length;i++) lightR[i]=new RectF();
            for(int i=0;i<gearLevelR.length;i++) gearLevelR[i]=new RectF();
        }

        @Override protected void onDraw(Canvas c){
            W=getWidth();
            H=getHeight();
            scale=Math.min(W/1536f, H/864f);
            drawBackdrop(c);
            drawHeader(c);
            drawTopStats(c);
            drawJoystickPanel(c);
            drawCenterPanels(c);
            drawRightPanel(c);
        }

        void txt(Canvas c,String s,float x,float y,float size,int color,Paint.Align align,boolean bold){
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setTextAlign(align);
            p.setTextSize(size*scale);
            p.setTypeface(Typeface.create(Typeface.SANS_SERIF,bold?Typeface.BOLD:Typeface.NORMAL));
            c.drawText(s,x,y,p);
        }

        void panel(Canvas c,RectF rr,int top,int bottom,int stroke,float radius){
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(rr.left,rr.top,rr.right,rr.bottom,top,bottom,Shader.TileMode.CLAMP));
            c.drawRoundRect(rr,radius*scale,radius*scale,p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.5f*scale);
            p.setColor(stroke);
            c.drawRoundRect(rr,radius*scale,radius*scale,p);
        }

        void glowStroke(Canvas c,RectF rr,int stroke,float radius){
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3*scale);
            p.setColor(stroke);
            p.setShadowLayer(16*scale,0,0,stroke);
            c.drawRoundRect(rr,radius*scale,radius*scale,p);
            p.clearShadowLayer();
        }

        void drawBackdrop(Canvas c){
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0,0,0,H,bgTop,bgBottom,Shader.TileMode.CLAMP));
            c.drawRect(0,0,W,H,p);
            p.setShader(null);
            p.setColor(Color.argb(40,20,110,255));
            c.drawCircle(W*0.24f,H*0.52f,220*scale,p);
            p.setColor(Color.argb(18,255,255,255));
            for(int i=0;i<5;i++) c.drawLine(24*scale,(18+i*168)*scale,W-24*scale,(18+i*168)*scale,p);
        }

        void drawHeader(Canvas c){
            RectF head=new RectF(14*scale,16*scale,W-14*scale,126*scale);
            panel(c,head,Color.rgb(8,12,20),Color.rgb(5,8,14),Color.rgb(32,40,58),18);

            profileR.set(30*scale,34*scale,102*scale,106*scale);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(18,30,48));
            c.drawCircle(profileR.centerX(),profileR.centerY(),profileR.width()/2f,p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3*scale);
            p.setColor(accent);
            c.drawCircle(profileR.centerX(),profileR.centerY(),profileR.width()/2f,p);
            txt(c,"◉",profileR.centerX(),profileR.centerY()+13*scale,28,white,Paint.Align.CENTER,true);

            txt(c,"◈",152*scale,84*scale,54,accent,Paint.Align.CENTER,true);
            txt(c,"PYIT TAING HTAUNG ROBOT",228*scale,70*scale,35,white,Paint.Align.LEFT,true);
            txt(c,"CONTROLLER",230*scale,108*scale,22,accent,Paint.Align.LEFT,true);

            btR.set(W-368*scale,38*scale,W-152*scale,102*scale);
            panel(c,btR,Color.rgb(11,16,24),Color.rgb(7,10,18),Color.rgb(34,44,62),24);
            txt(c,"◉",W-334*scale,82*scale,18,accent,Paint.Align.CENTER,true);
            txt(c,connected?"CONNECTED":"DISCONNECTED",W-248*scale,69*scale,21,connected?green:muted,Paint.Align.CENTER,true);
            txt(c,"ESP32 Robot",W-248*scale,97*scale,15,muted,Paint.Align.CENTER,false);

            settingsR.set(W-110*scale,36*scale,W-40*scale,106*scale);
            panel(c,settingsR,Color.rgb(11,16,24),Color.rgb(7,10,18),Color.rgb(34,44,62),24);
            txt(c,"⚙",settingsR.centerX(),settingsR.centerY()+12*scale,34,white,Paint.Align.CENTER,true);
        }

        void drawTopStats(Canvas c){
            float y1=146*scale, y2=278*scale, gap=12*scale;
            float start=14*scale;
            float available=W-28*scale-gap*3;
            float w1=available*0.34f, w2=available*0.22f, w3=available*0.22f, w4=available-(w1+w2+w3);
            RectF distanceR=new RectF(start,y1,start+w1,y2);
            danceR.set(distanceR.right+gap,y1,distanceR.right+gap+w2,y2);
            scaredR.set(danceR.right+gap,y1,danceR.right+gap+w3,y2);
            petR.set(scaredR.right+gap,y1,W-14*scale,y2);

            panel(c,distanceR,panelTop,panelBottom,panelStroke,18);
            panel(c,danceR,Color.rgb(18,16,34),Color.rgb(10,8,24),Color.rgb(74,64,120),18);
            panel(c,scaredR,Color.rgb(34,18,12),Color.rgb(22,10,8),Color.rgb(120,76,38),18);
            panel(c,petR,Color.rgb(14,24,18),Color.rgb(8,16,10),Color.rgb(58,102,70),18);

            txt(c,"◉",80*scale,228*scale,54,cyan,Paint.Align.CENTER,true);
            txt(c,"DISTANCE",128*scale,198*scale,24,accent,Paint.Align.LEFT,true);
            txt(c,String.format(Locale.US,"%.1f",distance),126*scale,250*scale,50,white,Paint.Align.LEFT,true);
            txt(c,"inch",228*scale,248*scale,22,white,Paint.Align.LEFT,false);
            drawMiniGraph(c,new RectF(distanceR.right-170*scale,184*scale,distanceR.right-44*scale,246*scale));

            txt(c,"♫",danceR.centerX(),danceR.top+64*scale,44,purple,Paint.Align.CENTER,true);
            txt(c,"DANCE",danceR.centerX(),danceR.top+108*scale,26,white,Paint.Align.CENTER,true);
            txt(c,"Show move",danceR.centerX(),danceR.top+132*scale,14,muted,Paint.Align.CENTER,false);

            txt(c,"!",scaredR.centerX(),scaredR.top+64*scale,44,orange,Paint.Align.CENTER,true);
            txt(c,"SCARED",scaredR.centerX(),scaredR.top+108*scale,26,white,Paint.Align.CENTER,true);
            txt(c,"Quick reaction",scaredR.centerX(),scaredR.top+132*scale,14,muted,Paint.Align.CENTER,false);

            txt(c,"♥",petR.centerX(),petR.top+64*scale,40,green,Paint.Align.CENTER,true);
            txt(c,"PET ROBOT",petR.centerX(),petR.top+108*scale,24,white,Paint.Align.CENTER,true);
            txt(c,"Friendly mode",petR.centerX(),petR.top+132*scale,14,muted,Paint.Align.CENTER,false);
        }

        void drawMiniGraph(Canvas c,RectF rr){
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2*scale);
            p.setColor(Color.rgb(70,78,98));
            for(int i=0;i<3;i++) c.drawLine(rr.left,rr.top+i*rr.height()/2f,rr.right,rr.top+i*rr.height()/2f,p);
            c.drawLine(rr.left,rr.top,rr.left,rr.bottom,p);
            float safeMax=30f;
            float normalized=Math.max(0f, Math.min(distance, safeMax))/safeMax;
            float y=rr.bottom-6*scale-normalized*(rr.height()-12*scale);
            int graphColor=distance<=6f?red:(distance<=12f?yellow:green);
            p.setColor(graphColor);
            p.setStrokeWidth(3*scale);
            float base=rr.bottom-6*scale;
            c.drawLine(rr.left+6*scale,base,rr.left+42*scale,base,p);
            c.drawLine(rr.left+42*scale,base,rr.centerX()-6*scale,y,p);
            c.drawLine(rr.centerX()-6*scale,y,rr.right-8*scale,y,p);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(rr.right-10*scale,y,4*scale,p);
            txt(c,"30",rr.left-8*scale,rr.top+8*scale,12,muted,Paint.Align.RIGHT,false);
            txt(c,"15",rr.left-8*scale,rr.centerY()+4*scale,12,muted,Paint.Align.RIGHT,false);
            txt(c,"0",rr.left-8*scale,rr.bottom+4*scale,12,muted,Paint.Align.RIGHT,false);
        }

        void drawJoystickPanel(Canvas c){
            float mainTop=294*scale;
            float mainBottom=H-16*scale;
            float leftW=(W-56*scale)*0.36f;
            RectF leftPanel=new RectF(14*scale,mainTop,14*scale+leftW,mainBottom);
            panel(c,leftPanel,panelTop,panelBottom,panelStroke,18);

            joyRad=Math.min(leftPanel.width(), leftPanel.height())*0.30f;
            joyCx=leftPanel.centerX();
            joyCy=leftPanel.top+leftPanel.height()*0.42f;

            if(W>=0){
                joyRad=Math.min(leftPanel.width(), leftPanel.height())*0.31f;
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.argb(28,41,130,255));
                c.drawCircle(joyCx,joyCy,joyRad+24*scale,p);
                p.setColor(Color.argb(16,120,220,255));
                c.drawCircle(joyCx,joyCy,joyRad*0.72f,p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(3*scale);
                p.setColor(Color.argb(80,95,180,255));
                c.drawCircle(joyCx,joyCy,joyRad*1.03f,p);
                c.drawCircle(joyCx,joyCy,joyRad*0.68f,p);

                float padSize=joyRad*0.92f;
                float btnSize=padSize*0.70f;
                float gap=padSize*0.13f;
                centerArrowR.set(joyCx-btnSize/2f,joyCy-btnSize/2f,joyCx+btnSize/2f,joyCy+btnSize/2f);
                upArrowR.set(joyCx-btnSize/2f,centerArrowR.top-btnSize-gap,joyCx+btnSize/2f,centerArrowR.top-gap);
                downArrowR.set(joyCx-btnSize/2f,centerArrowR.bottom+gap,joyCx+btnSize/2f,centerArrowR.bottom+gap+btnSize);
                leftArrowR.set(centerArrowR.left-btnSize-gap,joyCy-btnSize/2f,centerArrowR.left-gap,joyCy+btnSize/2f);
                rightArrowR.set(centerArrowR.right+gap,joyCy-btnSize/2f,centerArrowR.right+gap+btnSize,joyCy+btnSize/2f);

                drawArrowButton(c,upArrowR,activeDirection==1,1);
                drawArrowButton(c,downArrowR,activeDirection==2,2);
                drawArrowButton(c,leftArrowR,activeDirection==3,3);
                drawArrowButton(c,rightArrowR,activeDirection==4,4);
                panel(c,centerArrowR,Color.rgb(18,22,34),Color.rgb(8,11,18),Color.rgb(40,54,76),20);
                glowStroke(c,centerArrowR,Color.argb(90,80,120,170),20);
                txt(c,"STOP",centerArrowR.centerX(),centerArrowR.centerY()+8*scale,18,white,Paint.Align.CENTER,true);

                txt(c,"DRIVE CONTROL",leftPanel.centerX(),leftPanel.bottom-36*scale,18,cyan,Paint.Align.CENTER,true);
                txt(c,running?"Premium arrow pad active":"Press START then use arrows",leftPanel.centerX(),leftPanel.bottom-14*scale,13,muted,Paint.Align.CENTER,false);
                return;
            }

            if(W>=0){
                float padSize=joyRad*0.95f;
                float btnSize=padSize*0.72f;
                float gap=padSize*0.12f;
                centerArrowR.set(joyCx-btnSize/2f,joyCy-btnSize/2f,joyCx+btnSize/2f,joyCy+btnSize/2f);
                upArrowR.set(joyCx-btnSize/2f,centerArrowR.top-btnSize-gap,joyCx+btnSize/2f,centerArrowR.top-gap);
                downArrowR.set(joyCx-btnSize/2f,centerArrowR.bottom+gap,joyCx+btnSize/2f,centerArrowR.bottom+gap+btnSize);
                leftArrowR.set(centerArrowR.left-btnSize-gap,joyCy-btnSize/2f,centerArrowR.left-gap,joyCy+btnSize/2f);
                rightArrowR.set(centerArrowR.right+gap,joyCy-btnSize/2f,centerArrowR.right+gap+btnSize,joyCy+btnSize/2f);

                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.argb(18,41,130,255));
                c.drawCircle(joyCx,joyCy,joyRad+20*scale,p);

                drawArrowButton(c,upArrowR,activeDirection==1,"UP");
                drawArrowButton(c,downArrowR,activeDirection==2,"DOWN");
                drawArrowButton(c,leftArrowR,activeDirection==3,"LEFT");
                drawArrowButton(c,rightArrowR,activeDirection==4,"RIGHT");
                panel(c,centerArrowR,Color.rgb(16,20,30),Color.rgb(8,10,16),Color.rgb(34,44,62),18);
                txt(c,"STOP",centerArrowR.centerX(),centerArrowR.centerY()+8*scale,18,white,Paint.Align.CENTER,true);

                txt(c,"DRIVE CONTROL",leftPanel.centerX(),leftPanel.bottom-36*scale,18,cyan,Paint.Align.CENTER,true);
                txt(c,running?"Hold arrow to move":"Press START then use arrows",leftPanel.centerX(),leftPanel.bottom-14*scale,13,muted,Paint.Align.CENTER,false);
                return;
            }

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(18,41,130,255));
            c.drawCircle(joyCx,joyCy,joyRad+16*scale,p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(4*scale);
            p.setColor(accent);
            p.setShadowLayer(18*scale,0,0,accent);
            c.drawCircle(joyCx,joyCy,joyRad,p);
            p.clearShadowLayer();

            p.setColor(Color.rgb(38,42,52));
            p.setStrokeWidth(2*scale);
            c.drawCircle(joyCx,joyCy,joyRad-18*scale,p);
            c.drawCircle(joyCx,joyCy,joyRad*0.58f,p);
            c.drawCircle(joyCx,joyCy,joyRad*0.48f,p);

            p.setColor(Color.rgb(90,98,118));
            p.setStrokeWidth(6*scale);
            c.drawLine(joyCx-joyRad*0.78f,joyCy,joyCx-joyRad*0.63f,joyCy,p);
            c.drawLine(joyCx+joyRad*0.63f,joyCy,joyCx+joyRad*0.78f,joyCy,p);
            c.drawLine(joyCx,joyCy-joyRad*0.78f,joyCx,joyCy-joyRad*0.63f,p);
            c.drawLine(joyCx,joyCy+joyRad*0.63f,joyCx,joyCy+joyRad*0.78f,p);

            txt(c,"⌃",joyCx,joyCy-joyRad+78*scale,64,white,Paint.Align.CENTER,true);
            txt(c,"⌄",joyCx,joyCy+joyRad-34*scale,64,white,Paint.Align.CENTER,true);
            txt(c,"‹",joyCx-joyRad+44*scale,joyCy+18*scale,88,white,Paint.Align.CENTER,true);
            txt(c,"›",joyCx+joyRad-44*scale,joyCy+18*scale,88,white,Paint.Align.CENTER,true);

            RadialGradient knob=new RadialGradient(joyCx+joyX*joyRad*0.46f, joyCy+joyY*joyRad*0.46f, 56*scale, Color.rgb(90,214,255), accent, Shader.TileMode.CLAMP);
            p.setStyle(Paint.Style.FILL);
            p.setShader(knob);
            c.drawCircle(joyCx+joyX*joyRad*0.46f,joyCy+joyY*joyRad*0.46f,52*scale,p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3*scale);
            p.setColor(cyan);
            c.drawCircle(joyCx+joyX*joyRad*0.46f,joyCy+joyY*joyRad*0.46f,58*scale,p);

            txt(c,"DRIVE CONTROL",leftPanel.centerX(),leftPanel.bottom-36*scale,18,cyan,Paint.Align.CENTER,true);
            txt(c,running?"Live steering":"Touch joystick to move",leftPanel.centerX(),leftPanel.bottom-14*scale,13,muted,Paint.Align.CENTER,false);
        }

        void drawCenterPanels(Canvas c){
            float leftW=(W-56*scale)*0.36f;
            float rightW=(W-56*scale)*0.28f;
            float centerLeft=28*scale+leftW;
            float centerRight=W-28*scale-rightW;
            RectF speedPanel=new RectF(centerLeft,294*scale,centerRight,486*scale);
            RectF safetyPanel=new RectF(centerLeft,500*scale,centerRight,730*scale);
            RectF stopPanel=new RectF(centerLeft,744*scale,centerRight,H-16*scale);
            panel(c,speedPanel,panelTop,panelBottom,panelStroke,18);
            panel(c,safetyPanel,panelTop,panelBottom,panelStroke,18);
            panel(c,stopPanel,running?Color.rgb(8,30,14):Color.rgb(38,8,8),running?Color.rgb(6,20,10):Color.rgb(24,6,6),running?Color.rgb(30,120,55):Color.rgb(120,28,28),18);
            glowStroke(c,stopPanel,running?green:red,18);

            txt(c,"SPEED CONTROL",speedPanel.centerX(),speedPanel.top+42*scale,26,accent,Paint.Align.CENTER,true);
            speedBarR.set(speedPanel.left+42*scale,speedPanel.top+106*scale,speedPanel.right-42*scale,speedPanel.top+148*scale);
            panel(c,speedBarR,Color.rgb(12,14,18),Color.rgb(4,5,7),Color.rgb(28,38,56),22);
            float knobX=speedBarR.left+18*scale+(speed/100f)*(speedBarR.width()-36*scale);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(16*scale);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(26,34,46));
            c.drawLine(speedBarR.left+18*scale,speedBarR.centerY(),speedBarR.right-18*scale,speedBarR.centerY(),p);
            p.setColor(cyan);
            c.drawLine(speedBarR.left+18*scale,speedBarR.centerY(),knobX,speedBarR.centerY(),p);
            p.setStrokeWidth(2*scale);
            p.setColor(Color.argb(90,255,255,255));
            for(int i=0;i<=4;i++){
                float tickX=speedBarR.left+18*scale+((speedBarR.width()-36*scale)/4f)*i;
                c.drawLine(tickX,speedBarR.top+8*scale,tickX,speedBarR.bottom-8*scale,p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(knobX,speedBarR.centerY(),28*scale,Color.rgb(138,232,255),accent,Shader.TileMode.CLAMP));
            c.drawCircle(knobX,speedBarR.centerY(),26*scale,p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3*scale);
            p.setColor(white);
            c.drawCircle(knobX,speedBarR.centerY(),29*scale,p);
            speedKnobR.set(knobX-36*scale,speedBarR.centerY()-36*scale,knobX+36*scale,speedBarR.centerY()+36*scale);
            txt(c,String.format(Locale.US,"%d%%",Math.round(speed)),speedPanel.centerX(),speedPanel.top+88*scale,34,white,Paint.Align.CENTER,true);
            txt(c,"SLOW",speedBarR.left,speedPanel.bottom-34*scale,18,white,Paint.Align.LEFT,false);
            txt(c,"FAST",speedBarR.right,speedPanel.bottom-34*scale,18,white,Paint.Align.RIGHT,false);
            txt(c,"Drag for exact percentage",speedPanel.centerX(),speedPanel.bottom-12*scale,14,muted,Paint.Align.CENTER,false);
            if(W<0){
                speedBarR.set(speedPanel.left+52*scale,speedPanel.top+82*scale,speedPanel.right-52*scale,speedPanel.bottom-24*scale);
                panel(c,speedBarR,Color.rgb(12,14,18),Color.rgb(4,5,7),Color.rgb(28,38,56),24);
                float slotGap=10*scale;
                float slotH=(speedBarR.height()-slotGap*4)/3f;
                String[] labels={"GEAR 3","GEAR 2","GEAR 1"};
                String[] desc={"FAST","NORMAL","SLOW"};
                for(int i=0;i<3;i++){
                    float top=speedBarR.top+slotGap+(slotH+slotGap)*i;
                    gearLevelR[i].set(speedBarR.left+12*scale,top,speedBarR.right-12*scale,top+slotH);
                    boolean selected=gear==(3-i);
                    panel(c,gearLevelR[i],selected?Color.rgb(20,64,122):Color.rgb(10,14,20),selected?Color.rgb(14,42,84):Color.rgb(6,8,12),selected?accent:Color.rgb(24,32,48),18);
                    if(selected) glowStroke(c,gearLevelR[i],cyan,18);
                    txt(c,labels[i],gearLevelR[i].left+26*scale,gearLevelR[i].centerY()-4*scale,20,white,Paint.Align.LEFT,true);
                    txt(c,desc[i],gearLevelR[i].left+26*scale,gearLevelR[i].centerY()+20*scale,14,muted,Paint.Align.LEFT,false);
                    txt(c,String.valueOf(3-i),gearLevelR[i].right-28*scale,gearLevelR[i].centerY()+10*scale,30,selected?cyan:white,Paint.Align.CENTER,true);
                }
                speedKnobR.setEmpty();
            } else {
            speedBarR.set(speedPanel.left+36*scale,speedPanel.top+88*scale,speedPanel.right-36*scale,speedPanel.top+132*scale);
            panel(c,speedBarR,Color.rgb(12,14,18),Color.rgb(4,5,7),Color.rgb(28,38,56),20);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(14*scale);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(accent);
            float knobXLegacy=speedBarR.left+18*scale+(speed/100f)*(speedBarR.width()-36*scale);
            c.drawLine(speedBarR.left+18*scale,speedBarR.centerY(),knobXLegacy,speedBarR.centerY(),p);
            RadialGradient sg=new RadialGradient(knobXLegacy,speedBarR.centerY(),24*scale,Color.rgb(92,213,255),accent,Shader.TileMode.CLAMP);
            p.setStyle(Paint.Style.FILL);
            p.setShader(sg);
            c.drawCircle(knobXLegacy,speedBarR.centerY(),24*scale,p);
            p.setShader(null);
            speedKnobR.set(knobXLegacy-34*scale,speedBarR.centerY()-34*scale,knobXLegacy+34*scale,speedBarR.centerY()+34*scale);
            txt(c,"SLOW",speedPanel.left+44*scale,speedPanel.bottom-34*scale,18,white,Paint.Align.LEFT,false);
            txt(c,"NORMAL",speedPanel.centerX(),speedPanel.bottom-34*scale,18,white,Paint.Align.CENTER,true);
            txt(c,"FAST",speedPanel.right-44*scale,speedPanel.bottom-34*scale,18,white,Paint.Align.RIGHT,false);
            }

            RectF usRow=new RectF(safetyPanel.left+20*scale,safetyPanel.top+36*scale,safetyPanel.right-20*scale,safetyPanel.top+126*scale);
            RectF irRow=new RectF(safetyPanel.left+20*scale,safetyPanel.top+142*scale,safetyPanel.right-20*scale,safetyPanel.top+232*scale);
            panel(c,usRow,Color.rgb(12,14,18),Color.rgb(7,9,14),Color.rgb(33,43,63),16);
            panel(c,irRow,Color.rgb(12,14,18),Color.rgb(7,9,14),Color.rgb(33,43,63),16);
            txt(c,"⬡",usRow.left+38*scale,usRow.centerY()+10*scale,28,cyan,Paint.Align.CENTER,true);
            txt(c,"Obstacle Stop",usRow.left+78*scale,usRow.centerY()+2*scale,18,white,Paint.Align.LEFT,true);
            txt(c,"Auto brake at 6 inch",usRow.left+78*scale,usRow.centerY()+24*scale,13,muted,Paint.Align.LEFT,false);
            txt(c,"↶",irRow.left+38*scale,irRow.centerY()+10*scale,28,yellow,Paint.Align.CENTER,true);
            txt(c,"Edge Auto Back",irRow.left+78*scale,irRow.centerY()+2*scale,18,white,Paint.Align.LEFT,true);
            txt(c,"Reverse at floor edge",irRow.left+78*scale,irRow.centerY()+24*scale,13,muted,Paint.Align.LEFT,false);
            usToggleR.set(usRow.right-92*scale,usRow.top+16*scale,usRow.right-16*scale,usRow.bottom-16*scale);
            irToggleR.set(irRow.right-92*scale,irRow.top+16*scale,irRow.right-16*scale,irRow.bottom-16*scale);
            drawToggle(c,usToggleR,usSafe);
            drawToggle(c,irToggleR,irSafe);

            txt(c,running?"STOP":"START",stopPanel.centerX(),stopPanel.top+78*scale,54,white,Paint.Align.CENTER,true);
            txt(c,running?"RUNNING":"READY",stopPanel.centerX(),stopPanel.top+120*scale,24,running?green:yellow,Paint.Align.CENTER,true);
            txt(c,status,stopPanel.centerX(),stopPanel.top+152*scale,18,white,Paint.Align.CENTER,false);
            startStopR.set(stopPanel.left,stopPanel.top,stopPanel.right,stopPanel.bottom);
        }

        void drawArrowButton(Canvas c,RectF rr,boolean active,int direction){
            int top=active?Color.rgb(28,96,172):Color.rgb(16,20,32);
            int bottom=active?Color.rgb(10,52,108):Color.rgb(8,11,18);
            int stroke=active?cyan:Color.rgb(42,56,78);
            panel(c,rr,top,bottom,stroke,24);
            if(active) glowStroke(c,rr,cyan,24);

            float cx=rr.centerX(), cy=rr.centerY();
            float size=Math.min(rr.width(), rr.height())*0.26f;
            Path path=new Path();
            if(direction==1){
                path.moveTo(cx,cy-size*1.2f);
                path.lineTo(cx-size,cy+size*0.6f);
                path.lineTo(cx+size,cy+size*0.6f);
            } else if(direction==2){
                path.moveTo(cx,cy+size*1.2f);
                path.lineTo(cx-size,cy-size*0.6f);
                path.lineTo(cx+size,cy-size*0.6f);
            } else if(direction==3){
                path.moveTo(cx-size*1.2f,cy);
                path.lineTo(cx+size*0.6f,cy-size);
                path.lineTo(cx+size*0.6f,cy+size);
            } else {
                path.moveTo(cx+size*1.2f,cy);
                path.lineTo(cx-size*0.6f,cy-size);
                path.lineTo(cx-size*0.6f,cy+size);
            }
            path.close();

            p.setStyle(Paint.Style.FILL);
            p.setColor(white);
            c.drawPath(path,p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2*scale);
            p.setColor(Color.argb(120,255,255,255));
            c.drawPath(path,p);
        }

        void drawArrowButton(Canvas c,RectF rr,boolean active,String label){
            int top=active?Color.rgb(22,74,136):Color.rgb(14,18,28);
            int bottom=active?Color.rgb(12,44,88):Color.rgb(8,10,16);
            int stroke=active?cyan:Color.rgb(34,44,62);
            panel(c,rr,top,bottom,stroke,18);
            if(active) glowStroke(c,rr,cyan,18);
            txt(c,label,rr.centerX(),rr.centerY()+8*scale,18,white,Paint.Align.CENTER,true);
        }

        void drawToggle(Canvas c,RectF rr,boolean on){
            panel(c,rr,on?Color.rgb(34,204,53):Color.rgb(70,78,92),on?Color.rgb(28,182,45):Color.rgb(54,58,70),Color.TRANSPARENT,22);
            p.setStyle(Paint.Style.FILL);
            p.setColor(white);
            float cx=on?rr.right-22*scale:rr.left+22*scale;
            c.drawCircle(cx,rr.centerY(),18*scale,p);
        }

        void drawRightPanel(Canvas c){
            float rightW=(W-56*scale)*0.28f;
            RectF rightPanel=new RectF(W-14*scale-rightW,294*scale,W-14*scale,H-16*scale);
            panel(c,rightPanel,panelTop,panelBottom,panelStroke,18);
            txt(c,"LIGHT / EFFECTS",rightPanel.centerX(),rightPanel.top+42*scale,26,accent,Paint.Align.CENTER,true);

            float left=rightPanel.left+18*scale, top=rightPanel.top+72*scale, gap=14*scale;
            float cardW=(rightPanel.width()-gap*4)/3f;
            float cardH=(rightPanel.height()-126*scale-gap*3)/2f;
            lightR[0].set(left,top,left+cardW,top+cardH);
            lightR[1].set(left+cardW+gap,top,left+cardW*2+gap,top+cardH);
            lightR[2].set(left+cardW*2+gap*2,top,left+cardW*3+gap*2,top+cardH);
            lightR[3].set(left+(cardW*0.5f),top+cardH+gap,left+(cardW*1.5f),top+cardH*2+gap);
            lightR[4].set(left+(cardW*1.5f)+gap,top+cardH+gap,left+(cardW*2.5f)+gap,top+cardH*2+gap);

            drawLightCard(c,lightR[0],"POLICE",Color.rgb(255,75,75),light.equals("POLICE"),"◉");
            drawLightCard(c,lightR[1],"HAZARD",orange,light.equals("HAZARD"),"△");
            drawLightCard(c,lightR[2],"KNIGHT",purple,light.equals("KNIGHT RIDER"),"K");
            drawLightCard(c,lightR[3],"ALL ON",yellow,light.equals("ALL ON"),"☼");
            drawLightCard(c,lightR[4],"ALL OFF",white,light.equals("LIGHTS OFF"),"◌");
        }

        void drawLightCard(Canvas c,RectF rr,String label,int glow,boolean active,String icon){
            panel(c,rr,Color.rgb(13,11,14),Color.rgb(8,7,10),Color.rgb(40,40,48),18);
            if(active) glowStroke(c,rr,glow,18);
            RectF iconBox=new RectF(rr.left+18*scale,rr.top+18*scale,rr.right-18*scale,rr.top+102*scale);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(active?34:18,Color.red(glow),Color.green(glow),Color.blue(glow)));
            c.drawRoundRect(iconBox,16*scale,16*scale,p);
            txt(c,icon,rr.centerX(),rr.top+76*scale,34,glow,Paint.Align.CENTER,true);
            txt(c,label,rr.centerX(),rr.bottom-26*scale,15,active?white:glow,Paint.Align.CENTER,true);
        }

void showAboutMe() {
    new AlertDialog.Builder(MainActivity.this)
            .setTitle("ℹ About")
            .setMessage(
                    "🤖 Pyit Taing Htaung Robot Controller\n\n" +

                    "👨‍💻 Developer\n" +
                    "Feeder\n" +
                    "📞 09-959359747\n" +
                    "🌐 https://feeder.my-board.org/\n\n" +

                    "🏢 Supplier\n" +
                    "Pyit Taing Htaung Robot Controller\n" +
                    "📞 09-975976795\n\n" +

                    "━━━━━━━━━━━━━━━━━━━━\n\n" +

                    "💻 Software Support\n" +
                    "Software အသုံးပြုနေစဉ်အတွင်း Bug များ၊ Error များ သို့မဟုတ် " +
                    "System ပြဿနာများ ဖြစ်ပေါ်လာပါက Developer ထံသို့ " +
                    "တိုက်ရိုက် ဆက်သွယ်၍ အကူအညီ ရယူနိုင်ပါသည်။\n\n" +

                    "🔧 Hardware Support\n" +
                    "Hardware နှင့် ချိတ်ဆက်အသုံးပြုသည့် စက်ပစ္စည်းများ၊ " +
                    "ဝယ်ယူဖြန့်ချိရေးဆိုင်ရာ ကိစ္စရပ်များအတွက် Supplier ထံသို့ " +
                    "တိုက်ရိုက် ဆက်သွယ်နိုင်ပါသည်။\n\n" +

                    "🙏 အသုံးပြုသူများ၏ အဆင်ပြေချောမွေ့မှုအတွက် Developer နှင့် Supplier " +
                    "တို့မှ လိုအပ်သော အကူအညီများကို ပူးပေါင်းဆောင်ရွက်ပေးသွားမည် ဖြစ်ပါသည်။" +

                    "━━━━━━━━━━━━━━━━━━━━\n\n" +

"👨‍💻 To Developer\n\n" +

"Bluetooth Protocol\n\n" +

"🚀 Power\n" +
"START  | Enable Robot\n" +
"STOP   | Disable Robot\n\n" +

"🎮 Movement\n" +
"JOY:X,Y\n" +
"JOY:0,100   → Forward\n" +
"JOY:0,-100  → Backward\n" +
"JOY:-100,0  → Left\n" +
"JOY:100,0   → Right\n" +
"JOY:0,0     → Stop\n\n" +

"⚡ Speed\n" +
"SPEED:0~100\n\n" +


"🛡 Safety\n" +
"USON  | Obstacle Detect ON\n" +
"USOFF | Obstacle Detect OFF\n" +
"IRON  | Edge Detect ON\n" +
"IROFF | Edge Detect OFF\n\n" +

"💡 Lights\n" +
"LIGHT:POLICE\n" +
"LIGHT:HAZARD\n" +
"LIGHT:KNIGHT\n" +
"LIGHT:ON\n" +
"LIGHT:OFF\n\n" +

"🤖 Actions\n" +
"DANCE\n" +
"SCARED\n" +
"PET\n\n" +

"📡 Robot Response\n" +
"STATUS:READY\n" +
"STATUS:PAUSE\n" +
"DIST:value\n" +
"SPEED:value\n\n" +

"Developer Guide:\n" +
"Robot firmware supporting the above commands can connect directly with this application."
            )
            .setPositiveButton("OK", null)
            .show();
}

        void syncGearFromSpeed(){
            if(speed < 34) gear=1;
            else if(speed < 67) gear=2;
            else gear=3;
        }

        void syncSpeedFromGear(){
            if(gear<=1) speed=0;
            else if(gear==2) speed=50;
            else speed=100;
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            float x=e.getX(), y=e.getY();
            if(e.getAction()==MotionEvent.ACTION_DOWN){
                if(profileR.contains(x,y)){ showAboutMe(); return true; }
                if(btR.contains(x,y)){ showBtPicker(); return true; }
                if(settingsR.contains(x,y)){ startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return true; }
                if(danceR.contains(x,y)){ send("DANCE"); toast("Dance action sent"); return true; }
                if(scaredR.contains(x,y)){ send("SCARED"); toast("Scared action sent"); return true; }
                if(petR.contains(x,y)){ send("PET"); toast("Pet robot action sent"); return true; }
                if(startStopR.contains(x,y)){
                    running=!running;
                    status=running?"READY":"PAUSE";
                    if(running){
                        send("START");
                    } else {
                        activeDirection=0;
                        joyX=joyY=0;
                        send("STOP");
                        send("JOY:0,0");
                    }
                    invalidate();
                    return true;
                }
                if(usToggleR.contains(x,y)){ usSafe=!usSafe; send(usSafe?"USON":"USOFF"); invalidate(); return true; }
                if(irToggleR.contains(x,y)){ irSafe=!irSafe; send(irSafe?"IRON":"IROFF"); invalidate(); return true; }
                if(handleArrowTouch(x,y,true)) return true;
                for(int i=0;i<lightR.length;i++){
                    if(lightR[i].contains(x,y)){
                        String[] cmds={"LIGHT:POLICE","LIGHT:HAZARD","LIGHT:KNIGHT","LIGHT:ALLON","LIGHT:OFF"};
                        String[] names={"POLICE","HAZARD","KNIGHT RIDER","ALL ON","LIGHTS OFF"};
                        light=names[i];
                        if(i==3){ send("LIGHT:ON"); } else { send(cmds[i]); }
                        invalidate();
                        return true;
                    }
                }
                if(speedBarR.contains(x,y) || speedKnobR.contains(x,y)){
                    updateSpeedFromTouch(x);
                    return true;
                }
            }
            if(e.getAction()==MotionEvent.ACTION_MOVE){
                if(handleArrowTouch(x,y,false)) return true;
                if(speedBarR.left-18*scale <= x && x <= speedBarR.right+18*scale && speedBarR.top-20*scale <= y && y <= speedBarR.bottom+20*scale){
                    updateSpeedFromTouch(x);
                    return true;
                }
            }

            if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL){
                stopDirection();
                return true;
            }
            return true;
        }

        boolean handleArrowTouch(float x,float y,boolean allowCenterStop){
            int newDirection=0;
            if(upArrowR.contains(x,y)) newDirection=1;
            else if(downArrowR.contains(x,y)) newDirection=2;
            else if(leftArrowR.contains(x,y)) newDirection=3;
            else if(rightArrowR.contains(x,y)) newDirection=4;
            else if(allowCenterStop && centerArrowR.contains(x,y)){
                stopDirection();
                return true;
            }
            if(newDirection==0) return false;
            applyDirection(newDirection);
            return true;
        }

        void applyDirection(int direction){
            activeDirection=direction;
            if(direction==1){ joyX=0; joyY=-1; }
            else if(direction==2){ joyX=0; joyY=1; }
            else if(direction==3){ joyX=-1; joyY=0; }
            else if(direction==4){ joyX=1; joyY=0; }
            if(running) sendJoy(true);
            invalidate();
        }

        void stopDirection(){
            activeDirection=0;
            joyX=joyY=0;
            sendJoy(true);
            invalidate();
        }

        void updateSpeedFromTouch(float x){
            float clamped=Math.max(speedBarR.left+18*scale, Math.min(x, speedBarR.right-18*scale));
            speed=((clamped-(speedBarR.left+18*scale))/(speedBarR.width()-36*scale))*100f;
            syncGearFromSpeed();
            send("SPEED:"+Math.round(speed));
            send("GEAR:"+gear);
            invalidate();
        }

        void sendJoy(boolean force){
            long now=System.currentTimeMillis();
            if(!force && now-lastJoy<80)return;
            lastJoy=now;
            int x=Math.round(joyX*100);
            int y=Math.round(-joyY*100);
            if(Math.abs(x)<8)x=0;
            if(Math.abs(y)<8)y=0;
            send("JOY:"+x+","+y);
        }
    }
}
