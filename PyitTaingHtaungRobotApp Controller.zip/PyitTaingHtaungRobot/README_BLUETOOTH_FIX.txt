Pyit Taing Htaung Robot App - Bluetooth Permission Fixed Version

What was fixed:
1. Android 12+ runtime permissions added:
   - BLUETOOTH_CONNECT
   - BLUETOOTH_SCAN
2. Manifest uses BLUETOOTH_SCAN with neverForLocation.
3. Android 11 and below still use ACCESS_FINE_LOCATION for Bluetooth discovery.
4. Bluetooth picker is now easier:
   - Shows paired devices first, like Dabble style.
   - SCAN NEW button finds nearby Bluetooth devices.
   - PHONE BT SETTINGS button opens Android Bluetooth settings for pairing.

Recommended easy connection method:
1. Turn on ESP32 robot.
2. Phone Settings > Bluetooth > Pair new device.
3. Pair with: PyitTaingHtaung_Robot
4. Open this app.
5. Tap Bluetooth icon top-right.
6. Select the paired robot marked with ★ PAIRED.

If Android asks permission, tap Allow / Nearby devices.
